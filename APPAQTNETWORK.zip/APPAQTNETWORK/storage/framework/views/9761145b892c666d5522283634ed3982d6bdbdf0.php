<div class="simple-footer">
              Copyright &copy; Stisla 2018
            </div><?php /**PATH D:\PROJECT\APPAQTNETWORK\resources\views/components/footer.blade.php ENDPATH**/ ?>