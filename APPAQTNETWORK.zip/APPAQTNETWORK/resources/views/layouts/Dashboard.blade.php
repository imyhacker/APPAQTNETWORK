<x-head />
    <div id="app">
        <section class="section">
            <div class="container mt-5">
                <div class="row">
                    
                   @yield('content')
                </div>
        </section>
    </div>
<x-script />